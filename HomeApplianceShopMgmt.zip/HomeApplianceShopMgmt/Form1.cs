﻿using DGVPrinterHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeApplianceShopMgmt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            DataGridViewRow newRow = new DataGridViewRow();
            newRow.CreateCells(guna2DataGridView2);
            newRow.Cells[0].Value = Billing.id;
            newRow.Cells[1].Value = Billing.prod;
            newRow.Cells[3].Value = Billing.qty;
            newRow.Cells[2].Value = Billing.prce;
            newRow.Cells[4].Value = Billing.tot;

            totamt.Text = Billing.gtotal.ToString();

            guna2DataGridView2.Rows.Add(newRow);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            DGVPrinter print = new DGVPrinter();
            print.Title = "-Bill-";
            print.SubTitle = String.Format("Date:-{0}", DateTime.Now.ToUniversalTime());
            print.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            print.PageNumbers = true;
            print.PageNumberInHeader = false;
            print.PorportionalColumns = true;
            print.HeaderCellAlignment = StringAlignment.Near;
            print.Footer = "Total Payable Amount:" + totamt.Text;
            print.FooterSpacing = 15;
            print.PrintDataGridView(guna2DataGridView2);

            MessageBox.Show("Payment Successful");
        }
    }
}
