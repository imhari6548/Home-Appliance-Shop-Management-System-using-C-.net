﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HomeApplianceShopMgmt
{
    public partial class Login : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\tmhar\OneDrive\Documents\HomeAppliance.mdf;Integrated Security=True;Connect Timeout=30");

        public static string emp;

        private void reset()
        {
            username.Text = "";
            password.Text = "";
        }

        public Login()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (username.Text == "" || password.Text == "")
            {
                MessageBox.Show("Information missing!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    String query = "select empcode from usertb where Username = '" + username.Text + "' and password = '" + password.Text + "'";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    int codenum = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());

                    if (codenum == 1)
                    {
                        emp = username.Text;
                        Manager obj = new Manager();
                        obj.Show();
                        this.Hide();
                    }
                    else if (codenum == 2)
                    {
                        emp = username.Text;
                        Employee obj = new Employee();
                        obj.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password");
                        Login obj = new Login();
                        obj.Show();
                        this.Hide();
                    }

                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid Username or Password");
                    Login obj = new Login();
                    obj.Show();
                    this.Hide();
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            reset();
        }
    }
}
