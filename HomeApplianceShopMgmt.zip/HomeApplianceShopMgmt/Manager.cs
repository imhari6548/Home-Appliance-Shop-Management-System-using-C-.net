﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeApplianceShopMgmt
{
    public partial class Manager : Form
    {
        public Manager()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lOGOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void aDDEMPLOYEEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            createaccount obj = new createaccount();
            obj.Show();
            this.Hide();
        }

        private void eMPLOYEEMANAGEMENTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EmployeeMgmt obj = new EmployeeMgmt();  
            obj.Show();
            this.Hide();
        }

        private void aCCOUNTSETTINGSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AccountSettings1 obj = new AccountSettings1();
            obj.Show();
            this.Hide();
        }

        private void sALESREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report obj = new Report();
            obj.Show();
            this.Hide();
        }
    }
}
