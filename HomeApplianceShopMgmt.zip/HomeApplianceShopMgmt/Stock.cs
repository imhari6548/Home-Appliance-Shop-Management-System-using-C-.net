﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeApplianceShopMgmt
{
    public partial class Stock : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\tmhar\OneDrive\Documents\HomeAppliance.mdf;Integrated Security=True;Connect Timeout=30");

        private void displayStock()
        {
            con.Open();
            string query = "select Id,ProductName,Quantity,Brand,Category,Price,Supplier,Issue from stocktb";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            guna2DataGridView1.DataSource = ds.Tables[0];
            con.Close();
        }

        private void reset()
        {
            id.Text = "-";
            producttb.Text = "";
            quantitytb.Text = "";
            brandtb.Text = "";
            categorytb.Text = "";
            pricetb.Text = "";
            supplier.Text = "";
            issues.Text = "";
        }
        public Stock()
        {
            InitializeComponent();
            empName.Text = Login.emp;
            displayStock();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            id.Text = guna2DataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            producttb.Text = guna2DataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            quantitytb.Text = guna2DataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            brandtb.Text = guna2DataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            categorytb.Text = guna2DataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            pricetb.Text = guna2DataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            supplier.Text = guna2DataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            issues.Text = guna2DataGridView1.SelectedRows[0].Cells[7].Value.ToString();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            displayStock();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "update stocktb set Id='" + id.Text + "',ProductName='" + producttb.Text + "',Quantity='" + quantitytb.Text + "',Brand='" + brandtb.Text + "',Category='" + categorytb.Text + "',Price='" + pricetb.Text + "'  where Id=" + id.Text + "";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Stock Updated successfully!");
            con.Close();
            displayStock();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "select Id,ProductName,Quantity,Brand,Category,Price,Supplier from stocktb where ProductName = '" + producttb.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            guna2DataGridView1.DataSource = ds.Tables[0];
            con.Close();
            reset();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (producttb.Text == "" || issues.Text == "")
            {
                MessageBox.Show("Information missing!");
            }
            else
            {
                try
                {
                    con.Open();

                    string query = "update stocktb set Status=2,Issue='"+issues.Text+"' where ProductName='"+ producttb.Text + "'";


                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item deleted successfully!");

                    con.Close();

                    displayStock();
                    reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void quantitytb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Error,Cannot Contain Letters ");
            }
        }

        private void pricetb_TextChanged(object sender, EventArgs e)
        {

        }

        private void pricetb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Error,Cannot Contain Letters ");
            }
        }
    }
}
