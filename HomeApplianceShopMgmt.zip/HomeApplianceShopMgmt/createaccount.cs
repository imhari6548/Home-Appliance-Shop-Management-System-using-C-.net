﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeApplianceShopMgmt
{
    public partial class createaccount : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\tmhar\OneDrive\Documents\HomeAppliance.mdf;Integrated Security=True;Connect Timeout=30");

        private void displayEmp()
        {
            con.Open();
            string query = "select Username,EmpCode,phone,address from usertb";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            guna2DataGridView2.DataSource = ds.Tables[0];
            con.Close();
        }

        private void reset()
        {
            username.Text = "";
            password.Text = "";
            phoneno.Text = "";
            codenum.Text = "2";
            address.Text = "";
        }


        public createaccount()
        {
            InitializeComponent();

            empName.Text = Login.emp;

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            String query = "select max(id) from usertb";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            int count = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
            count = count + 1;

            id.Text = (count).ToString();

            codenum.Text = "2";
            displayEmp();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (username.Text == "" || password.Text == "" || codenum.Text == "" || phoneno.Text == "" || address.Text == "")
            {
                MessageBox.Show("Information missing!");
            }
            else if (!System.Text.RegularExpressions.Regex.IsMatch(username.Text, "^[a-zA-Z ]"))
            {
                MessageBox.Show("This textbox accepts only alphabetical characters!");
            }
            else if (!System.Text.RegularExpressions.Regex.IsMatch(phoneno.Text, "^[0-9]{10}"))
            {
                MessageBox.Show("Please enter 10 digits!");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into usertb values('" + id.Text + "','" + username.Text + "','" + password.Text + "','" + codenum.Text + "'," + phoneno.Text + ",'" + address.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Profile Created Successfully");

                    String query1 = "select max(id) from usertb";
                    SqlDataAdapter da = new SqlDataAdapter(query1, con);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    int count = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
                    count = count + 1;

                    id.Text = (count).ToString();

                    con.Close();
                    displayEmp();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Manager obj = new Manager();
            obj.Show();
            this.Hide();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Manager obj = new Manager();
            obj.Show();
            this.Hide();
        }

        private void phoneno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Error,Cannot Contain Letters ");
            }
        }

        private void phoneno_TextChanged(object sender, EventArgs e)
        {
            if (phoneno.TextLength == 10)
                phoneno.ForeColor = Color.Green;

            else
                phoneno.ForeColor = Color.Red;
        }
    }
}
