﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HomeApplianceShopMgmt
{

    public partial class AccountSettings2 : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\tmhar\OneDrive\Documents\HomeAppliance.mdf;Integrated Security=True;Connect Timeout=30");

        private void reset()
        {
            username.Text = "";
            password.Text = "";
            newpassword.Text = "";
            confmpassword.Text = "";
        }
        public AccountSettings2()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (username.Text == "" || password.Text == "" || newpassword.Text == "" || confmpassword.Text == "")
            {
                MessageBox.Show("Information missing!");
            }
            else
            {
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select count(*) from usertb where Username='" + username.Text + "' and password='" + password.Text + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                {
                    if (string.Equals(newpassword.Text, confmpassword.Text))
                    {
                        string query = "update usertb set password = '" + confmpassword.Text + "' where Username = '" + username.Text + "'";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Password reset was successful");
                        reset();
                    }
                    else
                    {
                        MessageBox.Show("Passwords doesn't match!");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password");
                }

                con.Close();
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }
    }
}
