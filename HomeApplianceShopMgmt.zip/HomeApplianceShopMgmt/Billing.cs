﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using DGVPrinterHelper;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace HomeApplianceShopMgmt
{
    public partial class Billing : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\tmhar\OneDrive\Documents\HomeAppliance.mdf;Integrated Security=True;Connect Timeout=30");

        public static int gtotal = 0,count = 0,n=0,id, tot;
        public static string  prod, qty, prce;
        private void displayEmp()
        {
            con.Open();
            string query = "select Id,productName,Quantity,Brand,Category,Price from stocktb where status=1";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            guna2DataGridView1.DataSource = ds.Tables[0];
            con.Close();
            n++;
        }

        private void billcount()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            String query = "select max(Id) from billtb";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            count = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
            count = count + 1;
        }
        public Billing()
        {
            InitializeComponent();

            billcount();

            displayEmp();

            empName.Text = Login.emp;
        }

        /*  int qty;
          private void getBonusAmt()
          {
              con.Open();
              string Query = "select * from stocktb where ProductName= '" + producttb.ToString() + "' ";
              SqlCommand cmd = new SqlCommand(Query, con);
              DataTable dt = new DataTable();
              SqlDataAdapter sda = new SqlDataAdapter(cmd);
              sda.Fill(dt);
              if (dt != null && dt.Rows.Count > 0)
              {
                  foreach (DataRow dr in dt.Rows)
                  {
                     qty  = dr["Quantity"].ToString();
                  }
              }
              con.Close();
          } */
      
        int oldqty = 0;
        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            producttb.Text = guna2DataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            pricetb.Text = guna2DataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            oldqty = Convert.ToInt32(guna2DataGridView1.SelectedRows[0].Cells[2].Value.ToString());
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            con.Open();
            if (cname.Text == "" || phno.Text == "")
            {
                MessageBox.Show("Information missing!");
            }
            else if (!System.Text.RegularExpressions.Regex.IsMatch(cname.Text, "^[a-zA-Z ]"))
            {
                MessageBox.Show("This textbox accepts only alphabetical characters!");
            }
            else
            {
                try
                {
                    


                    string query = "insert into billtb values( " + count + "," + DateTime.Now.Date.ToShortDateString() + ",'" + totamt.Text + "','" + cname.Text + "'," + phno.Text + ",'"+empName.Text+"')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Bill Generated");

                    billcount();


                    Form1 obj = new Form1();
                    obj.Show();
                    this.Hide();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            con.Close();
        }

        private void phno_TextChanged(object sender, EventArgs e)
        {
            if (phno.TextLength == 10)
                phno.ForeColor = Color.Green;

            else
                phno.ForeColor = Color.Red;
        }

        private void phno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Error,Cannot Contain Letters ");
            }
        }

        private void quantitytb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Error,Cannot Contain Letters ");
            }
        }

        private void empName_Click(object sender, EventArgs e)
        {

        }

        private void pricetb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Error,Cannot Contain Letters ");
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if(producttb.Text == "" || quantitytb.Text == "" || pricetb.Text == "")
            {
                MessageBox.Show("Information missing!");
            }
            else if(Convert.ToInt32(quantitytb.Text)>oldqty)
            {
                MessageBox.Show("Not Enough Stock!");
            }
            else
            {

                int value = oldqty - Convert.ToInt32(quantitytb.Text);
                con.Open();
                string query = "update stocktb set Quantity = @Value where ProductName = '" + producttb.Text + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Value", value);
                cmd.ExecuteNonQuery();
                con.Close();
                displayEmp();

                int total = Convert.ToInt32(quantitytb.Text) * Convert.ToInt32(pricetb.Text);
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(guna2DataGridView2);
                newRow.Cells[0].Value = n-1;
                id = n - 1;
                newRow.Cells[1].Value = producttb.Text;
                prod = producttb.Text;
                newRow.Cells[3].Value = quantitytb.Text;
                qty = quantitytb.Text;
                newRow.Cells[2].Value = pricetb.Text;
                prce = pricetb.Text;
                newRow.Cells[4].Value = total;
                tot = total;

                gtotal += total;
                totamt.Text = gtotal.ToString();

                guna2DataGridView2.Rows.Add(newRow);
            }
        }
    }
}
