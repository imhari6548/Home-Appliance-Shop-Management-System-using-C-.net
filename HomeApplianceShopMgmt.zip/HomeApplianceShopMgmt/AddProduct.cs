﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeApplianceShopMgmt
{
    public partial class AddProduct : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\tmhar\OneDrive\Documents\HomeAppliance.mdf;Integrated Security=True;Connect Timeout=30");

        private void reset()
        {
            productName.Text = "";
            quantity.Text = "";
            brand.Text = "";
            category.Text = "";
            price.Text = "";
            supplier.Text = "";
        }
        public AddProduct()
        {
            InitializeComponent();
            empName.Text = Login.emp;

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            String query = "select max(id) from stocktb";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            int count = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
            count = count + 1;

            id.Text = (count).ToString();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (productName.Text == "" || quantity.Text == "" || brand.Text == "" || category.Text == "" || price.Text == "" || supplier.Text =="")
            {
                MessageBox.Show("Information missing!");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into stocktb (Id,ProductName,Quantity,Brand,Category,Price,Supplier) values(" + id.Text + ",'" + productName.Text + "'," + quantity.Text + ",'" + brand.Text + "','" + category.Text + "'," + price.Text + ",'" + supplier.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Product Added Successfully");
                    con.Close();

                    AddProduct obj = new AddProduct();
                    obj.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void quantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Error,Cannot Contain Letters ");
            }
        }

        private void price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Error,Cannot Contain Letters ");
            }
        }
    }
}
